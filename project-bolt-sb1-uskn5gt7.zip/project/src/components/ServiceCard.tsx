import React from 'react';
import { motion } from 'framer-motion';

interface ServiceCardProps {
  title: string;
  description: string;
  imageUrl: string;
  delay?: number;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ 
  title, 
  description, 
  imageUrl,
  delay = 0 
}) => {
  return (
    <motion.div 
      className="bg-white rounded-lg shadow-md overflow-hidden group"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay }}
    >
      <div 
        className="h-56 bg-cover bg-center transform transition-transform duration-500 group-hover:scale-105"
        style={{ backgroundImage: `url(${imageUrl})` }}
      ></div>
      <div className="p-6">
        <h3 className="text-xl font-serif mb-3">{title}</h3>
        <p className="text-secondary-light">{description}</p>
      </div>
    </motion.div>
  );
};

export default ServiceCard;