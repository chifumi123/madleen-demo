import React from 'react';
import { motion } from 'framer-motion';

interface TeamMemberProps {
  name: string;
  role: string;
  imageUrl: string;
  delay?: number;
}

const TeamMember: React.FC<TeamMemberProps> = ({ 
  name, 
  role, 
  imageUrl,
  delay = 0 
}) => {
  return (
    <motion.div 
      className="text-center"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay }}
    >
      <div className="mb-4 relative overflow-hidden rounded-full w-48 h-48 mx-auto">
        <img 
          src={imageUrl} 
          alt={name} 
          className="w-full h-full object-cover transform transition-transform duration-500 hover:scale-110"
        />
      </div>
      <h3 className="text-xl font-serif">{name}</h3>
      <p className="text-primary">{role}</p>
    </motion.div>
  );
};

export default TeamMember;