import React from 'react';
import { motion } from 'framer-motion';

interface ProductCardProps {
  title: string;
  description?: string;
  imageUrl: string;
  brand?: string;
  delay?: number;
}

const ProductCard: React.FC<ProductCardProps> = ({ 
  title, 
  description, 
  imageUrl,
  brand,
  delay = 0 
}) => {
  return (
    <motion.div 
      className="bg-white rounded-lg shadow-md overflow-hidden group"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay }}
    >
      <div className="relative">
        <div 
          className="h-64 bg-cover bg-center transform transition-transform duration-500 group-hover:scale-105"
          style={{ backgroundImage: `url(${imageUrl})` }}
        ></div>
        {brand && (
          <div className="absolute top-3 right-3 bg-primary-light px-3 py-1 rounded text-xs font-medium">
            {brand}
          </div>
        )}
      </div>
      <div className="p-5">
        <h3 className="text-lg font-medium mb-2">{title}</h3>
        {description && <p className="text-secondary-light text-sm">{description}</p>}
      </div>
    </motion.div>
  );
};

export default ProductCard;