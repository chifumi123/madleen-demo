import React, { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, X, Scissors } from 'lucide-react';
import { AppointmentContext } from '../contexts/AppointmentContext';
import { motion } from 'framer-motion';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { openAppointmentModal } = React.useContext(AppointmentContext);
  const location = useLocation();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const closeMenu = () => setIsMenuOpen(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    closeMenu();
  }, [location]);

  const headerClass = isScrolled
    ? 'bg-white/90 shadow-md backdrop-blur-sm'
    : 'bg-white/90 backdrop-blur-sm';

  const navLinks = [
    { name: 'Accueil', path: '/' },
    { name: 'Notre salon', path: '/notre-salon' },
    { name: 'Coiffure', path: '/coiffure' },
    { name: 'Technique', path: '/technique' },
    { name: 'Nos produits', path: '/produits' },
    { name: 'Prothèses ongulaires', path: '/protheses-ongulaires' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <header className={`fixed w-full z-50 transition-all duration-300 ${headerClass}`}>
      <div className="container-custom py-4 flex justify-between items-center">
        <Link to="/" className="flex items-center">
          <Scissors className="text-primary h-6 w-6 mr-2" />
          <span className="font-serif text-xl md:text-2xl">
            Salon by Madleen
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:block">
          <ul className="flex gap-6 items-center">
            {navLinks.map((link) => (
              <li key={link.path}>
                <NavLink
                  to={link.path}
                  className={({ isActive }) =>
                    `relative py-2 text-sm font-medium transition-colors
                    ${isActive ? 'text-primary' : 'text-secondary hover:text-primary'}`
                  }
                >
                  {link.name}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-4">
          <button
            className="hidden md:block btn btn-primary text-sm"
            onClick={openAppointmentModal}
          >
            Prendre rendez-vous
          </button>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-secondary"
            onClick={toggleMenu}
            aria-label="Menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <motion.div
          className="md:hidden bg-white"
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          <nav className="container-custom py-6 border-t border-gray-100">
            <ul className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <li key={link.path}>
                  <NavLink
                    to={link.path}
                    className={({ isActive }) =>
                      `block py-2 text-base ${
                        isActive ? 'text-primary' : 'text-secondary'
                      }`
                    }
                    onClick={closeMenu}
                  >
                    {link.name}
                  </NavLink>
                </li>
              ))}
              <li className="mt-4">
                <button
                  className="btn btn-primary w-full"
                  onClick={openAppointmentModal}
                >
                  Prendre rendez-vous
                </button>
              </li>
            </ul>
          </nav>
        </motion.div>
      )}
    </header>
  );
};

export default Header;