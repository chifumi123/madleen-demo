import React, { useContext, useRef, useEffect } from 'react';
import { X, Phone } from 'lucide-react';
import { AppointmentContext } from '../contexts/AppointmentContext';
import { motion } from 'framer-motion';

const AppointmentModal: React.FC = () => {
  const { closeAppointmentModal } = useContext(AppointmentContext);
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        closeAppointmentModal();
      }
    };

    const handleClickOutside = (e: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(e.target as Node)) {
        closeAppointmentModal();
      }
    };

    document.addEventListener('keydown', handleEscape);
    document.addEventListener('mousedown', handleClickOutside);

    // Prevent scrolling on body
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.removeEventListener('mousedown', handleClickOutside);
      document.body.style.overflow = 'auto';
    };
  }, [closeAppointmentModal]);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <motion.div
        ref={modalRef}
        className="bg-white rounded-lg shadow-xl w-full max-w-md relative overflow-hidden"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
      >
        <div className="bg-primary p-6 text-center relative">
          <button
            onClick={closeAppointmentModal}
            className="absolute right-4 top-4 text-secondary hover:text-secondary-light transition-colors"
            aria-label="Fermer"
          >
            <X size={24} />
          </button>
          <h2 className="text-2xl font-serif">Prendre rendez-vous</h2>
          <p className="mt-2 text-secondary-light">
            Appelez-nous directement pour réserver votre prochain rendez-vous
          </p>
        </div>
        
        <div className="p-8 text-center">
          <div className="mb-6">
            <Phone size={32} className="mx-auto text-primary" />
          </div>
          <a
            href="tel:0238XXXXXX"
            className="text-3xl font-medium block hover:text-primary transition-colors"
          >
            02 38 XX XX XX
          </a>
          <p className="mt-4 text-gray-600">
            Mardi - Vendredi: 9h - 18h<br />
            Samedi: 9h - 17h
          </p>
          <button
            onClick={closeAppointmentModal}
            className="btn btn-outline mt-6 w-full"
          >
            Fermer
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default AppointmentModal;