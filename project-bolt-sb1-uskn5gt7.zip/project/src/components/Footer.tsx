import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Clock, Instagram, Facebook, Scissors } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-secondary text-white pt-12 pb-6">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center">
              <Scissors className="text-primary h-6 w-6 mr-2" />
              <h3 className="text-xl font-serif">Salon by Madleen</h3>
            </div>
            <p className="text-sm text-gray-300">
              Votre destination beauté à Fleury-les-Aubrais depuis plus de 18 ans.
            </p>
            <div className="flex space-x-4 pt-2">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white hover:text-primary transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white hover:text-primary transition-colors"
                aria-label="Facebook"
              >
                <Facebook size={20} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-medium mb-4">Coordonnées</h4>
            <ul className="space-y-3 text-sm text-gray-300">
              <li className="flex">
                <MapPin size={18} className="mr-2 flex-shrink-0 text-primary" />
                <span>123 rue des Coiffeurs, 45400 Fleury-les-Aubrais</span>
              </li>
              <li className="flex">
                <Phone size={18} className="mr-2 flex-shrink-0 text-primary" />
                <span>02 38 XX XX XX</span>
              </li>
              <li className="flex items-start">
                <Clock size={18} className="mr-2 flex-shrink-0 text-primary mt-1" />
                <div>
                  <p>Mardi - Vendredi: 9h - 18h</p>
                  <p>Samedi: 9h - 17h</p>
                  <p>Fermé le dimanche et lundi</p>
                </div>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-medium mb-4">Liens rapides</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li>
                <Link to="/" className="hover:text-primary transition-colors">
                  Accueil
                </Link>
              </li>
              <li>
                <Link to="/notre-salon" className="hover:text-primary transition-colors">
                  Notre salon
                </Link>
              </li>
              <li>
                <Link to="/coiffure" className="hover:text-primary transition-colors">
                  Coiffure
                </Link>
              </li>
              <li>
                <Link to="/technique" className="hover:text-primary transition-colors">
                  Technique
                </Link>
              </li>
              <li>
                <Link to="/produits" className="hover:text-primary transition-colors">
                  Nos produits
                </Link>
              </li>
              <li>
                <Link to="/protheses-ongulaires" className="hover:text-primary transition-colors">
                  Prothèses ongulaires
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-primary transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-medium mb-4">Moyens de paiement</h4>
            <p className="text-sm text-gray-300 mb-2">
              Nous acceptons les paiements par carte bancaire et en espèces.
            </p>
            <div className="flex space-x-2">
              <div className="bg-white text-secondary text-xs px-2 py-1 rounded">
                Carte bancaire
              </div>
              <div className="bg-white text-secondary text-xs px-2 py-1 rounded">
                Espèces
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-xs text-gray-400">
          <p>
            &copy; {currentYear} Salon de Coiffure by Madleen. Tous droits réservés.
          </p>
          <p className="mt-1">
            <Link to="/" className="hover:text-primary">
              Mentions légales
            </Link>{' '}
            |{' '}
            <Link to="/" className="hover:text-primary">
              Politique de confidentialité
            </Link>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;