import React, { createContext, useState, ReactNode } from 'react';

interface AppointmentContextType {
  isAppointmentModalOpen: boolean;
  openAppointmentModal: () => void;
  closeAppointmentModal: () => void;
}

const initialContext: AppointmentContextType = {
  isAppointmentModalOpen: false,
  openAppointmentModal: () => {},
  closeAppointmentModal: () => {},
};

export const AppointmentContext = createContext<AppointmentContextType>(initialContext);

interface AppointmentProviderProps {
  children: ReactNode;
}

export const AppointmentProvider: React.FC<AppointmentProviderProps> = ({ children }) => {
  const [isAppointmentModalOpen, setIsAppointmentModalOpen] = useState(false);

  const openAppointmentModal = () => setIsAppointmentModalOpen(true);
  const closeAppointmentModal = () => setIsAppointmentModalOpen(false);

  return (
    <AppointmentContext.Provider
      value={{
        isAppointmentModalOpen,
        openAppointmentModal,
        closeAppointmentModal,
      }}
    >
      {children}
    </AppointmentContext.Provider>
  );
};