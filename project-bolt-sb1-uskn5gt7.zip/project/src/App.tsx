import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';

// Layouts
import MainLayout from './layouts/MainLayout';

// Pages
import Home from './pages/Home';
import OurSalon from './pages/OurSalon';
import Hairstyling from './pages/Hairstyling';
import Technical from './pages/Technical';
import Products from './pages/Products';
import NailProsthetics from './pages/NailProsthetics';
import Contact from './pages/Contact';
import NotFound from './pages/NotFound';

// Context providers
import { AppointmentProvider } from './contexts/AppointmentContext';

function App() {
  return (
    <AppointmentProvider>
      <Router>
        <AnimatePresence mode="wait">
          <Routes>
            <Route path="/" element={<MainLayout />}>
              <Route index element={<Home />} />
              <Route path="notre-salon" element={<OurSalon />} />
              <Route path="coiffure" element={<Hairstyling />} />
              <Route path="technique" element={<Technical />} />
              <Route path="produits" element={<Products />} />
              <Route path="protheses-ongulaires" element={<NailProsthetics />} />
              <Route path="contact" element={<Contact />} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </AnimatePresence>
      </Router>
    </AppointmentProvider>
  );
}

export default App;