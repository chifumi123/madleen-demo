import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import Hero from '../components/Hero';
import ServiceCard from '../components/ServiceCard';
import { AppointmentContext } from '../contexts/AppointmentContext';
import { Scissors, MapPin, Star, Clock } from 'lucide-react';
import { motion } from 'framer-motion';

const Home: React.FC = () => {
  const { openAppointmentModal } = useContext(AppointmentContext);

  return (
    <>
      <Hero
        title="Salon de Coiffure by Madleen"
        subtitle="Votre destination beauté à Fleury-les-Aubrais"
        imageUrl="https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
      >
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={openAppointmentModal}
            className="btn btn-primary"
          >
            Prenez rendez-vous
          </button>
          <Link to="/contact" className="btn bg-white/20 backdrop-blur-sm text-white hover:bg-white/30">
            Contactez-nous
          </Link>
        </div>
      </Hero>

      <section className="section bg-white">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="section-title">Élégance & style dans un cadre chaleureux</h2>
              <p className="mb-6 text-secondary-light">
                Bienvenue au Salon de Coiffure by Madleen, votre espace beauté privilégié à Fleury-les-Aubrais. Notre équipe de professionnelles passionnées vous accueille dans un cadre élégant et convivial pour sublimer votre beauté.
              </p>
              <p className="mb-6 text-secondary-light">
                Que vous souhaitiez une coupe tendance, une coloration sur-mesure ou une manucure raffinée, nos expertes mettent leur savoir-faire à votre service pour des résultats qui vous ressemblent.
              </p>
              <Link to="/notre-salon" className="btn btn-outline">
                Découvrir notre salon
              </Link>
            </motion.div>
            <motion.div
              className="rounded-lg overflow-hidden shadow-lg"
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <img 
                src="https://images.pexels.com/photos/3992874/pexels-photo-3992874.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                alt="Intérieur du salon" 
                className="w-full h-96 object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-primary/10">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mx-auto after:left-1/2 after:-translate-x-1/2">Nos services</h2>
            <p className="max-w-2xl mx-auto text-secondary-light">
              Découvrez notre gamme complète de services capillaires et esthétiques pour sublimer votre beauté naturelle.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ServiceCard
              title="Coiffure"
              description="Coupes, brushings et coiffures personnalisées pour exprimer votre style unique."
              imageUrl="https://images.pexels.com/photos/3993305/pexels-photo-3993305.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
              delay={0.1}
            />
            <ServiceCard
              title="Technique"
              description="Colorations, balayages, mèches et permanentes réalisés par nos expertes visagistes."
              imageUrl="https://images.pexels.com/photos/3993443/pexels-photo-3993443.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
              delay={0.2}
            />
            <ServiceCard
              title="Prothèses ongulaires"
              description="Manucures, pose d'ongles en gel et vernis semi-permanent pour des mains parfaites."
              imageUrl="https://images.pexels.com/photos/704815/pexels-photo-704815.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
              delay={0.3}
            />
          </div>
          
          <div className="text-center mt-12">
            <Link to="/coiffure" className="btn btn-primary">
              Voir tous nos services
            </Link>
          </div>
        </div>
      </section>

      <section className="section bg-white">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <motion.div
              className="bg-primary/10 p-8 rounded-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <div className="flex items-center mb-6">
                <Star className="text-accent h-8 w-8 mr-3" />
                <h3 className="text-2xl font-serif">Ce que nos clientes disent</h3>
              </div>
              <blockquote className="text-secondary-light italic mb-6">
                "J'adore ce salon ! L'ambiance y est chaleureuse et l'équipe très professionnelle. Ma coiffeuse comprend toujours exactement ce que je veux et le résultat est toujours parfait. Je recommande vivement !"
              </blockquote>
              <p className="font-medium">- Sophie D., cliente fidèle</p>
            </motion.div>
            
            <motion.div
              className="bg-secondary p-8 text-white rounded-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
            >
              <div className="flex items-center mb-6">
                <Clock className="text-primary h-8 w-8 mr-3" />
                <h3 className="text-2xl font-serif">Plus de 18 ans d'expérience</h3>
              </div>
              <p className="mb-6">
                Notre salon met à votre service une expertise développée depuis plus de 18 ans dans le domaine de la coiffure et de l'esthétique.
              </p>
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-white/10 p-4 rounded">
                  <p className="text-3xl font-serif text-primary">4</p>
                  <p className="text-sm">Professionnelles</p>
                </div>
                <div className="bg-white/10 p-4 rounded">
                  <p className="text-3xl font-serif text-primary">18+</p>
                  <p className="text-sm">Années d'expérience</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="bg-primary/10 py-10">
        <div className="container-custom">
          <div className="bg-white p-6 md:p-8 rounded-lg shadow-md flex flex-col md:flex-row items-center justify-between">
            <div className="text-center md:text-left mb-6 md:mb-0">
              <h3 className="text-xl md:text-2xl font-serif mb-2">Prêt(e) à sublimer votre beauté ?</h3>
              <p className="text-secondary-light">Réservez votre rendez-vous dès maintenant</p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={openAppointmentModal}
                className="btn btn-primary"
              >
                Prendre rendez-vous
              </button>
              <Link to="/contact" className="btn btn-outline">
                Nous contacter
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;