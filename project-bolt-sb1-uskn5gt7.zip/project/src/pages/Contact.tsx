import React, { useContext } from 'react';
import Hero from '../components/Hero';
import ContactForm from '../components/ContactForm';
import { MapPin, Clock, Phone, Mail, CreditCard, Banknote } from 'lucide-react';
import { AppointmentContext } from '../contexts/AppointmentContext';
import { motion } from 'framer-motion';

const Contact: React.FC = () => {
  const { openAppointmentModal } = useContext(AppointmentContext);

  return (
    <>
      <Hero
        title="Contact"
        subtitle="Prenez rendez-vous ou venez nous rencontrer au salon"
        imageUrl="https://images.pexels.com/photos/3992861/pexels-photo-3992861.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260"
      >
        <button
          onClick={openAppointmentModal}
          className="btn btn-primary"
        >
          Téléphone du salon
        </button>
      </Hero>

      <section className="section bg-white">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="section-title">Contactez-nous</h2>
              <p className="mb-8 text-secondary-light">
                N'hésitez pas à nous contacter pour toute question, demande de rendez-vous ou information complémentaire. Nous vous répondrons dans les plus brefs délais.
              </p>
              
              <div className="space-y-6 mb-8">
                <div className="flex items-start">
                  <MapPin className="text-primary h-6 w-6 mr-4 mt-1" />
                  <div>
                    <h3 className="font-medium mb-1">Adresse</h3>
                    <p className="text-secondary-light">
                      123 rue des Coiffeurs<br />
                      45400 Fleury-les-Aubrais<br />
                      France
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Phone className="text-primary h-6 w-6 mr-4 mt-1" />
                  <div>
                    <h3 className="font-medium mb-1">Téléphone</h3>
                    <p className="text-secondary-light">
                      02 38 XX XX XX
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Mail className="text-primary h-6 w-6 mr-4 mt-1" />
                  <div>
                    <h3 className="font-medium mb-1">Email</h3>
                    <p className="text-secondary-light">
                      contact@salonbymadleen.fr
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <Clock className="text-primary h-6 w-6 mr-4 mt-1" />
                  <div>
                    <h3 className="font-medium mb-1">Horaires d'ouverture</h3>
                    <p className="text-secondary-light">
                      Mardi - Vendredi: 9h00 - 18h00<br />
                      Samedi: 9h00 - 17h00<br />
                      Fermé le dimanche et lundi
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-primary/10 p-5 rounded-lg">
                <h3 className="font-medium mb-3">Moyens de paiement acceptés</h3>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center">
                    <CreditCard className="text-secondary h-5 w-5 mr-2" />
                    <span>Carte bancaire</span>
                  </div>
                  <div className="flex items-center">
                    <Banknote className="text-secondary h-5 w-5 mr-2" />
                    <span>Espèces</span>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="bg-white rounded-lg shadow-md p-6 md:p-8">
                <h2 className="text-2xl font-serif mb-6">Envoyez-nous un message</h2>
                <ContactForm />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-primary/10">
        <div className="container-custom">
          <div className="text-center mb-8">
            <h2 className="section-title mx-auto after:left-1/2 after:-translate-x-1/2">Nous trouver</h2>
            <p className="max-w-2xl mx-auto text-secondary-light">
              Notre salon est idéalement situé au cœur de Fleury-les-Aubrais, facilement accessible en voiture et en transports en commun.
            </p>
          </div>
          
          <div className="bg-white rounded-lg overflow-hidden shadow-md h-96">
            {/* Placeholder for Google Maps, would be replaced with actual embed in production */}
            <img 
              src="https://images.pexels.com/photos/1007836/pexels-photo-1007836.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
              alt="Carte du salon" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      <section className="section bg-white">
        <div className="container-custom">
          <div className="bg-primary/10 rounded-lg p-8 md:p-12 text-center">
            <h2 className="text-2xl md:text-3xl font-serif mb-6">
              Suivez-nous sur les réseaux sociaux
            </h2>
            <p className="max-w-2xl mx-auto text-secondary-light mb-8">
              Découvrez nos dernières réalisations, nos conseils beauté et nos offres spéciales en nous suivant sur Instagram et Facebook.
            </p>
            <div className="flex justify-center space-x-6">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-primary flex items-center"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                </svg>
                Instagram
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-primary flex items-center"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                  <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                </svg>
                Facebook
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;