import React from 'react';
import PageHero from '../components/PageHero';
import ServiceCard from '../components/ServiceCard';
import { motion } from 'framer-motion';

const Hairstyling: React.FC = () => {
  const services = [
    {
      title: 'Coupe femme',
      description: 'Coupe personnalisée et adaptée à votre visage, suivie d\'un coiffage parfait.',
      imageUrl: 'https://images.pexels.com/photos/3992855/pexels-photo-3992855.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    },
    {
      title: 'Brushing',
      description: 'Mise en forme professionnelle pour un résultat impeccable et une coiffure qui tient.',
      imageUrl: 'https://images.pexels.com/photos/3993099/pexels-photo-3993099.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    },
    {
      title: 'Soins capillaires',
      description: 'Traitements profonds pour réparer, hydrater et sublimer vos cheveux.',
      imageUrl: 'https://images.pexels.com/photos/3997993/pexels-photo-3997993.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    },
    {
      title: 'Coiffures d\'événement',
      description: 'Créations sur-mesure pour vos occasions spéciales : mariages, cérémonies, soirées...',
      imageUrl: 'https://images.pexels.com/photos/1405699/pexels-photo-1405699.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    }
  ];

  return (
    <>
      <PageHero 
        title="Coiffure"
        subtitle="Exprimez votre style avec nos services de coiffure personnalisés"
      />

      <section className="section bg-white">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="section-title">Une coiffure qui vous ressemble</h2>
              <p className="mb-6 text-secondary-light">
                Chez Salon de Coiffure by Madleen, nous croyons que votre coiffure doit refléter votre personnalité. Nos coiffeuses visagistes analysent la forme de votre visage, la texture de vos cheveux et votre style de vie pour vous proposer une coiffure parfaitement adaptée.
              </p>
              <p className="mb-6 text-secondary-light">
                Que vous souhaitiez un rafraîchissement de votre coupe actuelle ou un changement complet de style, nous sommes là pour vous conseiller et réaliser la coiffure qui vous mettra en valeur.
              </p>
              <div className="bg-primary/10 p-5 rounded-lg">
                <p className="font-medium text-center">
                  "La meilleure coiffure est celle qui vous fait vous sentir bien dans votre peau."
                </p>
              </div>
            </motion.div>
            <motion.div
              className="rounded-lg overflow-hidden shadow-lg"
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <img 
                src="https://images.pexels.com/photos/3993320/pexels-photo-3993320.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                alt="Coiffure femme" 
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-primary/10">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mx-auto after:left-1/2 after:-translate-x-1/2">Nos services de coiffure</h2>
            <p className="max-w-2xl mx-auto text-secondary-light">
              Découvrez notre gamme complète de services capillaires pour sublimer votre beauté naturelle.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <ServiceCard
                key={service.title}
                title={service.title}
                description={service.description}
                imageUrl={service.imageUrl}
                delay={index * 0.1}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-white">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <motion.div
              className="bg-primary/10 p-8 rounded-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <div className="text-primary text-4xl font-serif mb-4">01</div>
              <h3 className="text-xl font-medium mb-4">Consultation personnalisée</h3>
              <p className="text-secondary-light">
                Nos coiffeuses prennent le temps d'échanger avec vous pour comprendre vos envies, vos habitudes et votre style de vie avant de commencer toute coupe.
              </p>
            </motion.div>
            
            <motion.div
              className="bg-primary/10 p-8 rounded-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
            >
              <div className="text-primary text-4xl font-serif mb-4">02</div>
              <h3 className="text-xl font-medium mb-4">Expertise visagiste</h3>
              <p className="text-secondary-light">
                Nos professionnelles sont formées en visagisme et savent quelle coupe mettra en valeur les traits de votre visage et sublimera votre beauté naturelle.
              </p>
            </motion.div>
            
            <motion.div
              className="bg-primary/10 p-8 rounded-lg"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
            >
              <div className="text-primary text-4xl font-serif mb-4">03</div>
              <h3 className="text-xl font-medium mb-4">Produits de qualité</h3>
              <p className="text-secondary-light">
                Nous utilisons exclusivement des produits professionnels Wella qui respectent vos cheveux tout en offrant des résultats exceptionnels et durables.
              </p>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Hairstyling;