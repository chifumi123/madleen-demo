import React from 'react';
import { Link } from 'react-router-dom';
import { Scissors } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 text-center">
      <Scissors className="text-primary h-16 w-16 mb-6" />
      <h1 className="text-4xl md:text-5xl font-serif mb-4">Page non trouvée</h1>
      <p className="text-secondary-light max-w-md mb-8">
        Désolé, la page que vous recherchez n'existe pas ou a été déplacée.
      </p>
      <Link to="/" className="btn btn-primary">
        Retour à l'accueil
      </Link>
    </div>
  );
};

export default NotFound;