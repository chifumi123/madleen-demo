import React from 'react';
import PageHero from '../components/PageHero';
import TeamMember from '../components/TeamMember';
import { MapPin, Clock, PhoneCall } from 'lucide-react';
import { motion } from 'framer-motion';

const OurSalon: React.FC = () => {
  const teamMembers = [
    {
      name: 'Madleen',
      role: 'Fondatrice & Coiffeuse',
      imageUrl: 'https://images.pexels.com/photos/3998423/pexels-photo-3998423.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    },
    {
      name: 'Sophie',
      role: 'Coiffeuse Visagiste',
      imageUrl: 'https://images.pexels.com/photos/3373716/pexels-photo-3373716.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    },
    {
      name: 'Emma',
      role: 'Coloriste',
      imageUrl: 'https://images.pexels.com/photos/774095/pexels-photo-774095.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    },
    {
      name: 'Julie',
      role: 'Prothésiste Ongulaire',
      imageUrl: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    }
  ];

  return (
    <>
      <PageHero 
        title="Notre Salon"
        subtitle="Découvrez notre équipe de professionnelles passionnées et notre espace beauté"
      />

      <section className="section bg-white">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="section-title">Bienvenue dans notre univers</h2>
              <p className="mb-6 text-secondary-light">
                Depuis plus de 18 ans, le Salon de Coiffure by Madleen est devenu une référence à Fleury-les-Aubrais. Notre équipe de professionnelles passionnées vous accueille dans un espace élégant et chaleureux, conçu pour votre bien-être.
              </p>
              <p className="mb-6 text-secondary-light">
                Chez nous, chaque cliente est unique. Nous prenons le temps de vous écouter, de comprendre vos envies et de vous conseiller pour sublimer votre beauté naturelle.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mt-8">
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mr-4">
                    <span className="font-serif text-primary text-xl">01</span>
                  </div>
                  <span>Passion</span>
                </div>
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mr-4">
                    <span className="font-serif text-primary text-xl">02</span>
                  </div>
                  <span>Expertise</span>
                </div>
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mr-4">
                    <span className="font-serif text-primary text-xl">03</span>
                  </div>
                  <span>Convivialité</span>
                </div>
              </div>
            </motion.div>
            <motion.div
              className="rounded-lg overflow-hidden shadow-lg"
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <img 
                src="https://images.pexels.com/photos/705255/pexels-photo-705255.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                alt="Intérieur du salon" 
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-primary/10">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mx-auto after:left-1/2 after:-translate-x-1/2">Notre équipe</h2>
            <p className="max-w-2xl mx-auto text-secondary-light">
              Découvrez les professionnelles passionnées qui composent notre équipe et qui mettent leur expertise à votre service.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <TeamMember
                key={member.name}
                name={member.name}
                role={member.role}
                imageUrl={member.imageUrl}
                delay={index * 0.1}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mx-auto after:left-1/2 after:-translate-x-1/2">Nous trouver</h2>
            <p className="max-w-2xl mx-auto text-secondary-light">
              Situé au cœur de Fleury-les-Aubrais, notre salon vous accueille dans un cadre élégant et convivial.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12">
            <motion.div
              className="h-80 md:h-auto bg-gray-200 rounded-lg overflow-hidden"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              {/* Placeholder for Google Maps, would be replaced with actual embed in production */}
              <img 
                src="https://images.pexels.com/photos/1007836/pexels-photo-1007836.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                alt="Carte du salon" 
                className="w-full h-full object-cover"
              />
            </motion.div>
            
            <motion.div
              className="space-y-8"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
            >
              <div>
                <div className="flex items-center mb-4">
                  <MapPin className="text-primary h-6 w-6 mr-3" />
                  <h3 className="text-xl font-medium">Adresse</h3>
                </div>
                <p className="text-secondary-light">
                  123 rue des Coiffeurs<br />
                  45400 Fleury-les-Aubrais<br />
                  France
                </p>
              </div>
              
              <div>
                <div className="flex items-center mb-4">
                  <Clock className="text-primary h-6 w-6 mr-3" />
                  <h3 className="text-xl font-medium">Horaires d'ouverture</h3>
                </div>
                <ul className="space-y-2 text-secondary-light">
                  <li className="flex justify-between">
                    <span>Lundi</span>
                    <span className="font-medium">Fermé</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Mardi - Vendredi</span>
                    <span className="font-medium">9h00 - 18h00</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Samedi</span>
                    <span className="font-medium">9h00 - 17h00</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Dimanche</span>
                    <span className="font-medium">Fermé</span>
                  </li>
                </ul>
              </div>
              
              <div>
                <div className="flex items-center mb-4">
                  <PhoneCall className="text-primary h-6 w-6 mr-3" />
                  <h3 className="text-xl font-medium">Contact</h3>
                </div>
                <p className="text-secondary-light mb-1">
                  Téléphone : 02 38 XX XX XX
                </p>
                <p className="text-secondary-light">
                  Email : contact@salonbymadleen.fr
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default OurSalon;