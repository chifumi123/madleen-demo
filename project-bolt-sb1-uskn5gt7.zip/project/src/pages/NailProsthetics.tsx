import React from 'react';
import PageHero from '../components/PageHero';
import ServiceCard from '../components/ServiceCard';
import { motion } from 'framer-motion';

const NailProsthetics: React.FC = () => {
  const services = [
    {
      title: 'Pose d\'ongles en gel',
      description: 'Allongement et renforcement de vos ongles naturels pour un résultat durable et élégant.',
      imageUrl: 'https://images.pexels.com/photos/3997386/pexels-photo-3997386.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    },
    {
      title: 'Manucure complète',
      description: 'Soin complet des mains et des ongles pour une apparence soignée et raffinée.',
      imageUrl: 'https://images.pexels.com/photos/939836/pexels-photo-939836.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    },
    {
      title: 'Vernis semi-permanent',
      description: 'Couleur intense et brillance qui tient jusqu\'à trois semaines sans s\'écailler.',
      imageUrl: 'https://images.pexels.com/photos/704815/pexels-photo-704815.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    }
  ];

  return (
    <>
      <PageHero 
        title="Prothèses ongulaires"
        subtitle="Des ongles parfaits qui subliment vos mains"
      />

      <section className="section bg-white">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="section-title">L'art des ongles par Julie</h2>
              <p className="mb-6 text-secondary-light">
                Notre prothésiste ongulaire Julie vous accueille tous les vendredis au salon pour sublimer vos mains et vos ongles. Experte en pose d'ongles en gel, manucures soignées et vernis semi-permanent, elle saura mettre en valeur vos mains avec élégance.
              </p>
              <p className="mb-6 text-secondary-light">
                Que ce soit pour une occasion spéciale ou pour le quotidien, offrez-vous des ongles parfaits qui complèteront votre look avec style.
              </p>
              <div className="bg-primary/10 p-5 rounded-lg">
                <p className="font-medium">
                  <span className="block text-lg mb-2">Disponibilité :</span>
                  Tous les vendredis de 9h à 18h, sur rendez-vous
                </p>
              </div>
            </motion.div>
            <motion.div
              className="rounded-lg overflow-hidden shadow-lg"
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <img 
                src="https://images.pexels.com/photos/4210347/pexels-photo-4210347.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                alt="Prothèses ongulaires" 
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-primary/10">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mx-auto after:left-1/2 after:-translate-x-1/2">Nos prestations ongulaires</h2>
            <p className="max-w-2xl mx-auto text-secondary-light">
              Découvrez nos services de prothèses ongulaires pour des mains élégantes et soignées.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard
                key={service.title}
                title={service.title}
                description={service.description}
                imageUrl={service.imageUrl}
                delay={index * 0.1}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-white">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              className="order-2 md:order-1"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="grid grid-cols-2 gap-4">
                <img 
                  src="https://images.pexels.com/photos/3997304/pexels-photo-3997304.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                  alt="Nail art 1" 
                  className="rounded-lg h-40 object-cover"
                />
                <img 
                  src="https://images.pexels.com/photos/1638344/pexels-photo-1638344.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                  alt="Nail art 2" 
                  className="rounded-lg h-40 object-cover"
                />
                <img 
                  src="https://images.pexels.com/photos/3997499/pexels-photo-3997499.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                  alt="Nail art 3" 
                  className="rounded-lg h-40 object-cover"
                />
                <img 
                  src="https://images.pexels.com/photos/939835/pexels-photo-939835.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                  alt="Nail art 4" 
                  className="rounded-lg h-40 object-cover"
                />
              </div>
            </motion.div>
            
            <motion.div
              className="order-1 md:order-2"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="section-title">Personnalisez vos ongles</h2>
              <p className="mb-6 text-secondary-light">
                Exprimez votre style avec notre service de nail art personnalisé. Des designs élégants aux créations plus audacieuses, notre prothésiste ongulaire saura réaliser le nail art qui vous correspond.
              </p>
              <ul className="space-y-3 mb-6">
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                  <span>French manucure classique ou revisitée</span>
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                  <span>Effets marbrés, dégradés ou métallisés</span>
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                  <span>Motifs géométriques ou floraux</span>
                </li>
                <li className="flex items-center">
                  <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                  <span>Strass, paillettes et ornements</span>
                </li>
              </ul>
              <p className="text-secondary-light">
                Chaque prestation inclut une consultation pour déterminer la forme, la longueur et le design qui vous conviennent le mieux.
              </p>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default NailProsthetics;