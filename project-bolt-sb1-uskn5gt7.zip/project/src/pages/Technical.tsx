import React from 'react';
import PageHero from '../components/PageHero';
import ServiceCard from '../components/ServiceCard';
import { motion } from 'framer-motion';

const Technical: React.FC = () => {
  const services = [
    {
      title: 'Coloration complète',
      description: 'Changez de couleur ou camouflez vos cheveux blancs avec nos colorations riches et lumineuses.',
      imageUrl: 'https://images.pexels.com/photos/3993456/pexels-photo-3993456.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    },
    {
      title: 'Balayage & Mèches',
      description: 'Apportez dimension et profondeur à votre chevelure avec nos techniques de balayage naturel.',
      imageUrl: 'https://images.pexels.com/photos/4722305/pexels-photo-4722305.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    },
    {
      title: 'Permanente & Lissage',
      description: 'Transformez la texture de vos cheveux pour des boucles durables ou un lissage parfait.',
      imageUrl: 'https://images.pexels.com/photos/1306049/pexels-photo-1306049.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'
    }
  ];

  return (
    <>
      <PageHero 
        title="Technique"
        subtitle="Des prestations techniques pour transformer et sublimer votre chevelure"
      />

      <section className="section bg-white">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="section-title">L'expertise technique au service de votre beauté</h2>
              <p className="mb-6 text-secondary-light">
                Nos services techniques vont bien au-delà d'une simple coloration. Nos coloristes expérimentées utilisent des techniques avancées et des produits de qualité Wella pour transformer vos cheveux tout en préservant leur santé.
              </p>
              <p className="mb-6 text-secondary-light">
                Que vous souhaitiez raviver votre couleur naturelle, tenter une nouvelle teinte ou apporter du mouvement à vos cheveux, nous réalisons vos envies avec précision et soin.
              </p>
              <div className="flex items-center p-4 bg-primary/10 rounded-lg">
                <img 
                  src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Wella_logo.svg/2560px-Wella_logo.svg.png" 
                  alt="Wella Professionals" 
                  className="h-12 mr-4"
                />
                <p className="text-sm">
                  Nous utilisons exclusivement les produits Wella Professionals pour des résultats de qualité salon.
                </p>
              </div>
            </motion.div>
            <motion.div
              className="rounded-lg overflow-hidden shadow-lg"
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <img 
                src="https://images.pexels.com/photos/3993313/pexels-photo-3993313.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                alt="Service technique" 
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-primary/10">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mx-auto after:left-1/2 after:-translate-x-1/2">Nos services techniques</h2>
            <p className="max-w-2xl mx-auto text-secondary-light">
              Des prestations expertes pour transformer votre couleur et la texture de vos cheveux.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard
                key={service.title}
                title={service.title}
                description={service.description}
                imageUrl={service.imageUrl}
                delay={index * 0.1}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-white">
        <div className="container-custom">
          <h2 className="section-title text-center mx-auto after:left-1/2 after:-translate-x-1/2 mb-16">
            Notre expertise technique
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <motion.div
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <div className="h-64 mb-6 rounded-lg overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/3065209/pexels-photo-3065209.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                  alt="Changement de style" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-serif mb-3">Changez de style</h3>
              <p className="text-secondary-light">
                Osez la transformation avec nos colorations complètes qui respectent la santé de vos cheveux.
              </p>
            </motion.div>
            
            <motion.div
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
            >
              <div className="h-64 mb-6 rounded-lg overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/3993333/pexels-photo-3993333.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                  alt="Boucles durables" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-serif mb-3">Boucles durables</h3>
              <p className="text-secondary-light">
                Nos permanentes modernes créent des boucles naturelles et des ondulations qui durent.
              </p>
            </motion.div>
            
            <motion.div
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4 }}
            >
              <div className="h-64 mb-6 rounded-lg overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/3993450/pexels-photo-3993450.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                  alt="Expertise visagiste" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-serif mb-3">Expertise visagiste</h3>
              <p className="text-secondary-light">
                Nos techniciennes évaluent votre carnation et la forme de votre visage pour une couleur parfaitement adaptée.
              </p>
            </motion.div>
          </div>
          
          <div className="text-center">
            <p className="italic text-secondary-light max-w-2xl mx-auto mb-8">
              "Nous réalisons une consultation approfondie avant chaque service technique pour comprendre vos attentes et vous proposer la solution la plus adaptée."
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Technical;