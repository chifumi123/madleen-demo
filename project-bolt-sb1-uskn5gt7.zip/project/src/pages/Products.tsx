import React from 'react';
import PageHero from '../components/PageHero';
import ProductCard from '../components/ProductCard';
import { motion } from 'framer-motion';

const Products: React.FC = () => {
  const products = [
    {
      title: 'Shampooing réparateur',
      description: 'Réparation intense pour cheveux abîmés et fragilisés.',
      imageUrl: 'https://images.pexels.com/photos/3735652/pexels-photo-3735652.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      brand: 'Wella'
    },
    {
      title: 'Après-shampooing hydratant',
      description: 'Hydratation profonde pour des cheveux doux et soyeux.',
      imageUrl: 'https://images.pexels.com/photos/3737579/pexels-photo-3737579.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      brand: 'Wella'
    },
    {
      title: 'Masque nourrissant',
      description: 'Soin intensif hebdomadaire pour une nutrition en profondeur.',
      imageUrl: 'https://images.pexels.com/photos/3737586/pexels-photo-3737586.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      brand: 'Wella'
    },
    {
      title: 'Sérum anti-frisottis',
      description: 'Contrôle des frisottis et brillance instantanée.',
      imageUrl: 'https://images.pexels.com/photos/4465124/pexels-photo-4465124.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      brand: 'Wella'
    },
    {
      title: 'Spray volumisant',
      description: 'Volume et tenue pour les cheveux fins et sans volume.',
      imageUrl: 'https://images.pexels.com/photos/3737590/pexels-photo-3737590.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      brand: 'Wella'
    },
    {
      title: 'Huile protectrice',
      description: 'Protection thermique et nutrition pour tous types de cheveux.',
      imageUrl: 'https://images.pexels.com/photos/3685530/pexels-photo-3685530.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      brand: 'Wella'
    },
    {
      title: 'Mousse coiffante',
      description: 'Fixation souple et naturelle pour tous styles de coiffure.',
      imageUrl: 'https://images.pexels.com/photos/4202325/pexels-photo-4202325.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      brand: 'Wella'
    },
    {
      title: 'Laque professionnelle',
      description: 'Fixation forte et durable sans effet carton.',
      imageUrl: 'https://images.pexels.com/photos/3785147/pexels-photo-3785147.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
      brand: 'Wella'
    },
  ];

  return (
    <>
      <PageHero 
        title="Nos produits"
        subtitle="Des produits capillaires professionnels pour sublimer vos cheveux"
      />

      <section className="section bg-white">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="section-title">La qualité professionnelle à domicile</h2>
              <p className="mb-6 text-secondary-light">
                Pour prolonger les bienfaits de votre visite au salon, nous proposons une sélection de produits capillaires professionnels Wella, utilisés et recommandés par nos coiffeuses.
              </p>
              <p className="mb-6 text-secondary-light">
                Ces produits de haute qualité sont spécialement formulés pour répondre aux besoins spécifiques de chaque type de cheveux et vous permettent de maintenir des résultats professionnels entre deux visites.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mt-8">
                <div className="flex-1 bg-primary/10 p-4 rounded-lg text-center">
                  <h3 className="font-medium mb-2">Conseils personnalisés</h3>
                  <p className="text-sm text-secondary-light">
                    Nos coiffeuses vous conseillent les produits adaptés à vos besoins.
                  </p>
                </div>
                <div className="flex-1 bg-primary/10 p-4 rounded-lg text-center">
                  <h3 className="font-medium mb-2">Qualité salon</h3>
                  <p className="text-sm text-secondary-light">
                    Des formules professionnelles pour des résultats optimaux.
                  </p>
                </div>
              </div>
            </motion.div>
            <motion.div
              className="rounded-lg overflow-hidden shadow-lg"
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <img 
                src="https://images.pexels.com/photos/3997389/pexels-photo-3997389.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" 
                alt="Produits capillaires" 
                className="w-full h-full object-cover"
              />
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-primary/10">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="section-title mx-auto after:left-1/2 after:-translate-x-1/2">Notre gamme de produits</h2>
            <p className="max-w-2xl mx-auto text-secondary-light">
              Découvrez notre sélection de produits capillaires professionnels pour tous types de cheveux.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((product, index) => (
              <ProductCard
                key={product.title}
                title={product.title}
                description={product.description}
                imageUrl={product.imageUrl}
                brand={product.brand}
                delay={index * 0.05}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-white">
        <div className="container-custom">
          <div className="bg-primary/10 rounded-lg p-8 md:p-12">
            <div className="text-center mb-8">
              <h2 className="text-2xl md:text-3xl font-serif mb-4">
                Pourquoi choisir des produits professionnels ?
              </h2>
              <p className="max-w-2xl mx-auto text-secondary-light">
                Les produits professionnels offrent de nombreux avantages par rapport aux produits grand public.
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              <motion.div
                className="bg-white p-6 rounded-lg shadow-sm"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <h3 className="text-xl font-medium mb-3">Formules concentrées</h3>
                <p className="text-secondary-light">
                  Les produits professionnels contiennent des ingrédients actifs plus concentrés qui offrent des résultats supérieurs.
                </p>
              </motion.div>
              
              <motion.div
                className="bg-white p-6 rounded-lg shadow-sm"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
              >
                <h3 className="text-xl font-medium mb-3">Ingrédients de qualité</h3>
                <p className="text-secondary-light">
                  Des ingrédients sélectionnés avec soin pour préserver la santé de vos cheveux tout en offrant performance et efficacité.
                </p>
              </motion.div>
              
              <motion.div
                className="bg-white p-6 rounded-lg shadow-sm"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.4 }}
              >
                <h3 className="text-xl font-medium mb-3">Résultats durables</h3>
                <p className="text-secondary-light">
                  Des formules développées pour offrir des résultats professionnels durables entre deux visites au salon.
                </p>
              </motion.div>
            </div>
            
            <div className="text-center mt-8">
              <p className="italic text-secondary-light">
                "Demandez conseil à nos coiffeuses pour découvrir les produits adaptés à vos besoins et à votre type de cheveux."
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Products;