/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#f8c8dc', // powder pink
          light: '#fde5ee',
          dark: '#e0a0b8',
        },
        secondary: {
          DEFAULT: '#000000', // black
          light: '#333333',
        },
        accent: {
          DEFAULT: '#a0d2eb', // light blue
          light: '#c9e6f7',
          dark: '#7ab9e0',
        },
        background: {
          DEFAULT: '#ffffff', // white
          light: '#f9f9f9',
          dark: '#f0f0f0',
        }
      },
      fontFamily: {
        sans: ['Montserrat', 'sans-serif'],
        serif: ['Playfair Display', 'serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.5s ease-in-out',
        'slide-up': 'slideUp 0.5s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
};